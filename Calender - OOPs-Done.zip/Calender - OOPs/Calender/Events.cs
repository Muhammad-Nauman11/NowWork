﻿using System;
using System.Windows.Forms;

namespace Calender
{
    public partial class EventSavingForm : Form
    {
        public delegate void MarkEvented();
        public event MarkEvented OnEventAdditions;
        public event MarkEvented OnEventDeletions;
        public int dateOfDay;
        public int month;
        public int year;



        //Constructor
        public EventSavingForm(int day,int iMonth, int iYear)
        {
            dateOfDay = day;
            month = iMonth;
            year = iYear;
            InitializeComponent();
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void EventSavingForm_Load(object sender, EventArgs e)
        {
            txtDate.Text = dateOfDay + "/" + month + "/" + year;
            txtDate.ReadOnly = true;

        }

        private void btnSave_Click(object sender, EventArgs e)
        {

            string descriptions = txtEvent.Text;
            if (descriptions!="") 
            {
                Calendar.eventsData[$"{month:00}/{dateOfDay:00}"] = $"{descriptions}";
                OnEventAdditions.Invoke();
            }
            Close();

        }
        private void btnDelete_Click(object sender, EventArgs e)
        {

            string descriptions = txtEvent.Text;
            Calendar.eventsData.Remove($"{month:00}/{dateOfDay:00}");
            OnEventDeletions.Invoke();         
            Close();

        }
        private void txtEvent_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
