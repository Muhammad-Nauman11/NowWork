﻿
namespace Calender
{
    partial class DateBoxFill
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        public void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.btnDateFill = new System.Windows.Forms.Button();
            this.ttpDescription = new System.Windows.Forms.ToolTip(this.components);
            this.SuspendLayout();
            // 
            // btnDateFill
            // 
            this.btnDateFill.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(60)))), ((int)(((byte)(60)))), ((int)(((byte)(60)))));
            this.btnDateFill.FlatAppearance.BorderSize = 0;
            this.btnDateFill.FlatAppearance.MouseDownBackColor = System.Drawing.Color.LightGray;
            this.btnDateFill.FlatAppearance.MouseOverBackColor = System.Drawing.Color.DarkGray;
            this.btnDateFill.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnDateFill.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnDateFill.ForeColor = System.Drawing.Color.White;
            this.btnDateFill.Location = new System.Drawing.Point(0, 0);
            this.btnDateFill.Margin = new System.Windows.Forms.Padding(2);
            this.btnDateFill.Name = "btnDateFill";
            this.btnDateFill.Size = new System.Drawing.Size(41, 36);
            this.btnDateFill.TabIndex = 1;
            this.btnDateFill.Text = "b";
            this.btnDateFill.UseVisualStyleBackColor = false;
            // 
            // DateBoxFill
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(40)))), ((int)(((byte)(40)))));
            this.Controls.Add(this.btnDateFill);
            this.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.Margin = new System.Windows.Forms.Padding(2);
            this.Name = "DateBoxFill";
            this.Size = new System.Drawing.Size(41, 38);
            this.Load += new System.EventHandler(this.DateBoxFill_Load);
            this.ResumeLayout(false);

        }

        #endregion
        public System.Windows.Forms.Button btnDateFill;
        public System.Windows.Forms.ToolTip ttpDescription;
    }
}
