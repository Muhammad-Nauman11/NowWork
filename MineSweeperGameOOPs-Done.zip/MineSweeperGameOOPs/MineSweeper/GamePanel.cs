﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace MineSweeper
{
    public partial class GamePanel : UserControl
    {
        public GamePanel()
        {
            InitializeComponent();
        }

        private void GamePanel_Load(object sender, EventArgs e)
        {
            //when game panel will be loaded then its size will be updated as well as its location
            int windowW, windowH;

            windowW = this.Parent.Size.Width;//getting parent window width, it is main window
            windowH = this.Parent.Size.Height;//getting parent window height
            this.Size = new Size(windowW-windowW/5,windowH-windowH/6);//game panel size updating
            this.Location = new Point((windowW-this.Size.Width)/2,(windowH-this.Size.Height)/2);//game panel location updaing to make it almost at window center
            
        }
        public void button1_Click(object sender, EventArgs e) 
        {
            Console.WriteLine();
        }
    }
}
